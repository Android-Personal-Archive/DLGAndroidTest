package com.mcs.dlgandroidtest

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.collection.ArrayMap
import kotlinx.android.synthetic.main.activity_account_signup.*
import java.util.*
import kotlin.collections.ArrayList

var emailList = ArrayList<String>()
class AccountSignupActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_account_signup)

        ibtn_back_nav.setOnClickListener {
            moveToMainActivity()
        }

        btn_next.setOnClickListener {
            moveToDashboardActivity()
        }

        var email = ""
        var password = ""
        var passwordMatch = ""
        et_email.addTextChangedListener(object : TextWatcher{
            override fun afterTextChanged(p0: Editable?) {
                email = p0.toString()
                if(!p0.toString().isValidEmail()) {
                    ll_error_email_invalid.visibility = View.VISIBLE
                    btn_next.isEnabled = false
                }
                else if(emailList.contains(p0.toString())) {
                    ll_error_email_exists.visibility = View.VISIBLE
                    btn_next.isEnabled = false
                }
                else {
                    ll_error_email_invalid.visibility = View.GONE
                    ll_error_email_exists.visibility = View.GONE
                    if(password.isValidPassword() && passwordMatch == password)
                        btn_next.isEnabled = true
                }
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
        })

        et_password.addTextChangedListener(object : TextWatcher{
            override fun afterTextChanged(p0: Editable?) {
                password = p0.toString()
                if(!p0.toString().isValidPassword()) {
                    ll_error_password_invalid.visibility = View.VISIBLE
                    btn_next.isEnabled = false
                }
                else {
                    ll_error_password_invalid.visibility = View.GONE
                    if(email.isValidEmail() && passwordMatch == password)
                        btn_next.isEnabled = true
                }
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
        })

        et_password_repeat.addTextChangedListener(object : TextWatcher{
            override fun afterTextChanged(p0: Editable?) {
                passwordMatch = p0.toString()
                if(p0.toString() != password) {
                    ll_error_password_mismatch.visibility = View.VISIBLE
                    btn_next.isEnabled = false
                }
                else {
                    ll_error_password_mismatch.visibility = View.GONE
                    if(email.isValidEmail() && password.isValidPassword())
                        btn_next.isEnabled = true
                }
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
        })
    }

    private fun moveToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    private fun moveToDashboardActivity() {
        emailList.add(et_email.text.toString())

        //look into simplifying with .apply if that's what it's used for (RE: putExtra)
        val intent = Intent(this, DashboardActivity::class.java)
        intent.putExtra(EXTRA_INPUT_EMAIL, et_email.text.toString())
        startActivity(intent)
    }

    companion object{
        val EXTRA_INPUT_EMAIL = "ExtraEmail"
    }

    private fun String.isValidEmail() : Boolean =
        this.isNotEmpty() && android.util.Patterns.EMAIL_ADDRESS.matcher(this).matches()

    private fun String.isValidPassword() : Boolean {
        if(this.isEmpty() || !this.contains("(?=.*[a-z])".toRegex()) || !this.contains("(?=.*[A-Z])".toRegex()) || !this.contains("(?=.*\\d)".toRegex()) || this.length < 8)
            return false;

        return true
    }
}